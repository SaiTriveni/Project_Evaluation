package com.capgemini.library_management_system_jpa_corejava.dao;

import java.util.List;

import com.capgemini.library_management_system_jpa_corejava.dto.BookDto;
import com.capgemini.library_management_system_jpa_corejava.dto.InformationDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface, it has all the method signatures of Admin only which in turn helps in achieving 100% abstraction.
 * This is an example of achieving 100% abstraction.
 *
 */
public interface AdminDao {
	
	boolean register(InformationDto admin);
	boolean auth(String email,String password);
	boolean addBook(BookDto book);
	List<BookDto> searchBookTitle(String bookTitle);
	List<BookDto> searchBookAuthor(String bookAuthor);
	List<BookDto> searchBookType(String bookType);
	boolean updateBook(int bookId,String bookAuthor);
	boolean removeBook(int bookId);
	List<BookDto> getBooksInfo();

	boolean issueBook(int bookId, int userId);
	boolean returnBook(int userId, int bookId);
	
}
