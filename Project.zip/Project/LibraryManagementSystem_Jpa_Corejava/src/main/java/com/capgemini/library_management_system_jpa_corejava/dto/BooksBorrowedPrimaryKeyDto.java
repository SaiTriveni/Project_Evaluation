package com.capgemini.library_management_system_jpa_corejava.dto;

import java.io.Serializable;

import javax.persistence.Embeddable;

import lombok.Data;

/**
 * 
 * @author Sai Triveni
 * This class implements Serializable interface and creates foreign key relation to bookDto.
 *
 */
@Data
@Embeddable
public class BooksBorrowedPrimaryKeyDto implements Serializable{

	@SuppressWarnings("unused")
	private int bookId;

	@SuppressWarnings("unused")
	private String email;
}
