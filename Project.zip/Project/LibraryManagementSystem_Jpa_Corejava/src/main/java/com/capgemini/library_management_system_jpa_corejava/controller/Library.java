package com.capgemini.library_management_system_jpa_corejava.controller;
 
/**
 * 
 * @author Sai Triveni
 * This is a class, execution starts from here.
 */
public class Library {
	
	/**
	 * This is main method, execution starts from this method.
	 * @param args
	 */
	public static void main(String[] args) {
		Librarian librarian=new Librarian();
		librarian.start();
	} 
}