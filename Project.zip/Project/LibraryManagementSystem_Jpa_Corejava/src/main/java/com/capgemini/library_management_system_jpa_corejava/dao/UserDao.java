package com.capgemini.library_management_system_jpa_corejava.dao;

import java.util.List;

import com.capgemini.library_management_system_jpa_corejava.dto.BookDto;
import com.capgemini.library_management_system_jpa_corejava.dto.InformationDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface, it has all the method signatures of User only which in turn helps in achieving 100% abstraction.
 * This is an example of achieving 100% abstraction.
 */
public interface UserDao {
	boolean register(InformationDto std);
	List<BookDto> searchBookTitle(String bookName);
	List<BookDto> searchBookAuthor(String bookAuthor);
	List<BookDto> searchBookType(String bookType);
	List<BookDto> getBooksInfo();
	boolean requestBook(int bookId,int userId);
	boolean returnBook(int bookId,int userId);
	
	

}
