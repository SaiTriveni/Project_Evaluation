package com.capgemini.library_management_system_jpa_corejava.dto;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.Data;
import lombok.EqualsAndHashCode.Exclude;

/**
 * 
 * @author Sai Triveni
 * This is a class which takes care of the issue book details.
 * It also has an object of its foreign key created in another class called BookIssueDetailsPrimaryKeyDto.
 * This class also considers util.Date to get system date.
 *
 */
@Data
@Entity
@Table(name = "bookissue")
public class BookIssueDetailsDto {

	@EmbeddedId
	private BookIssueDetailsPrimaryKeyDto bookIssueDetailsPrimaryKey;
	
	@Column
	private int id;
	

	@Temporal(TemporalType.DATE)
	@Column(name = "issueDate")
	private java.util.Date Date = new java.util.Date();
	@Column
	private Date returnDate;

	 @Exclude 
	  
	  @ManyToOne(cascade=CascadeType.ALL)
	  
	  @JoinColumn(name="id" , insertable = false,updatable = false)
	  private InformationDto primary;
	 
}
