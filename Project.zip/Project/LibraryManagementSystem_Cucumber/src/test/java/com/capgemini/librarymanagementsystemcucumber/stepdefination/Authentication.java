package com.capgemini.librarymanagementsystemcucumber.stepdefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Authentication {

	WebDriver driver;
	static {

		System.setProperty("webdriver.chrome.driver",
				"F:\\ProjectWorkspace\\librarymanagementsystemcucumber\\src\\main\\resource\\driver1\\chromedriver.exe");
	}

	@Given("^User Is On Registration Page$")
	public void user_Is_On_Registration_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.get("http://localhost:4200/authenticate");

	}

	@When("^User gave details (\\d+),\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_gave_details(int arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
		driver.findElement(By.id("userName")).sendKeys(arg2);
		driver.findElement(By.id("email")).sendKeys(arg3);
		driver.findElement(By.id("password")).sendKeys(arg4);
		driver.findElement(By.id("role")).click();
		driver.findElement(By.xpath("//option[@value=\"admin\"]")).click();
		driver.findElement(By.xpath("//button[text()='Register']")).click();

	}

	@Then("^User Should Return \"([^\"]*)\"$")
	public void user_Should_Return(String arg1) throws Throwable {

		String actual = driver.getTitle();
		String expected = "LibraryManagement";
		Assert.assertEquals(expected, actual);
		driver.close();
	}

	@Given("^User Is On Login Page and user enters email$")
	public void user_Is_On_Login_Page_and_user_enters_email() throws Throwable {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);

		driver.get("http://localhost:4200/login");
		driver.findElement(By.id("email")).sendKeys("aravind@gmail.com");
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		driver.findElement(By.id("password")).sendKeys("Aravind@12");
		driver.findElement(By.xpath("//button[text()='Login']")).click();
	}

	@Then("^user should login$")
	public void user_should_login() throws Throwable {
		String actual = driver.getTitle();
		System.out.println(actual);
		driver.close();
}
}
