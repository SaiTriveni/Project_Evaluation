package com.capgemini.librarymanagementsystemcucumber.stepdefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AdminOperations {
	WebDriver driver;
	static {

		System.setProperty("webdriver.chrome.driver",
				"F:\\ProjectWorkspace\\librarymanagementsystemcucumber\\src\\main\\resource\\driver1\\chromedriver.exe");
	}

	@Given("^user enter the url of the website$")
	public void user_enter_the_url_of_the_website() throws Throwable {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.get("http://localhost:4200/login");

	}

	@When("^User enters login valid credentials$")
	public void user_enters_login_valid_credentials() throws Throwable {
		driver.findElement(By.id("email")).sendKeys("aravind@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Aravind@12");
		driver.findElement(By.xpath("//button[text()='Login']")).click();
	}

	@Then("^User should navigate to Login$")
	public void user_should_navigate_to_Login() throws Throwable {
		System.out.println(driver.getTitle());
	}

	@When("^Admin gave book details (\\d+),\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void admin_gave_book_details(int arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {

		driver.findElement(By.xpath("//li[@class=\"nav-item active\"]")).click();
		driver.findElement(By.xpath("//a[text()='View page']")).click();
		driver.findElement(By.id("bookName")).sendKeys(arg2);
		driver.findElement(By.id("author")).sendKeys(arg3);
		driver.findElement(By.id("category")).sendKeys(arg4);
		driver.findElement(By.id("publisher")).sendKeys(arg5);
		driver.findElement(By.xpath("//button[contains(text(),' Add Book ')]")).click();
		driver.findElement(By.cssSelector("#update")).click();

	}

	@Then("^Book Should Return \"([^\"]*)\"$")
	public void book_Should_Return(String arg1) throws Throwable {

		driver.findElement(By.id("bookName")).clear();
		driver.findElement(By.id("bookName")).sendKeys("Capgemini");
		driver.findElement(By.xpath("//button[contains(text(),' UpdateBook ')]")).click();
		Thread.sleep(3000);
		driver.close();
	}

	@When("^Admin gave details <bid>,\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void admin_gave_details_bid(String arg1, String arg2, String arg3, String arg4) throws Throwable {
		driver.findElement(By.xpath("//li[@class=\"nav-item active\"]")).click();
		driver.findElement(By.xpath("//a[text()='View page']")).click();
		driver.findElement(By.id("bookName")).sendKeys(arg1);
		driver.findElement(By.id("author")).sendKeys(arg2);
		driver.findElement(By.id("category")).sendKeys(arg3);
		driver.findElement(By.id("publisher")).sendKeys(arg4);
		driver.findElement(By.xpath("//button[contains(text(),' Add Book ')]")).click();
		driver.findElement(By.cssSelector("#delete")).click();
	}

	@Then("^Book is deleted$")
	public void book_is_deleted() throws Throwable {

		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		driver.close();
	}

	@Given("^Admin is showing the list of requests$")
	public void admin_is_showing_the_list_of_requests() throws Throwable {
		driver.findElement(By.xpath("//li[@class=\"nav-item active\"]")).click();
		driver.findElement(By.xpath("(//a[text()='View page'])[4]")).click();

	}

	@Then("^List of requests are returned$")
	public void list_of_requests_are_returned() throws Throwable {
		System.out.println(driver.getTitle());
	
		Thread.sleep(3000);
		driver.close();
	}

	@When("^Admin gave details (\\d+), (\\d+)$")
	public void admin_gave_details(int arg1, int arg2) throws Throwable {
		driver.findElement(By.xpath("//li[@class=\"nav-item active\"]")).click();
		driver.findElement(By.xpath("(//a[text()='View page'])[4]")).click();
		driver.findElement(By.xpath("//tr[1]//td[6]//button[1]")).click();
	}

	@Then("^Book is issued$")
	public void book_is_issued() throws Throwable {
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		driver.close();
	}

	@When("^Admin gave user Id details (\\d+)$")
	public void admin_gave_user_Id_details(int arg1) throws Throwable {
		driver.findElement(By.xpath("//li[@class=\"nav-item active\"]")).click();
		driver.findElement(By.xpath("(//a[text()='View page'])[3]")).click();

	}

	@Then("^List of issued books is displayed$")
	public void list_of_issued_books_is_displayed() throws Throwable {
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		driver.close();
	}

	@Given("^Admin is cancelling book request$")
	public void admin_is_cancelling_book_request() throws Throwable {
		driver.findElement(By.xpath("//li[@class=\"nav-item active\"]")).click();
		driver.findElement(By.xpath("(//a[text()='View page'])[4]")).click();
	}

	@When("^Admin has given details (\\d+),(\\d+)$")
	public void admin_has_given_details(int arg1, int arg2) throws Throwable {
		driver.findElement(By.xpath("//tr[1]//td[7]//button[1]")).click();
	}

	@Then("^Book request has been cancelled$")
	public void book_request_has_been_cancelled() throws Throwable {
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		driver.close();
	}

	@When("^Admin call it$")
	public void admin_call_it() throws Throwable {
		driver.findElement(By.xpath("//li[@class=\"nav-item active\"]")).click();
		driver.findElement(By.xpath("(//a[text()='View page'])[5]")).click();
	}

	@Then("^List of users are returned$")
	public void list_of_users_are_returned() throws Throwable {
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		driver.close();
	}

	@When("^Admin calls it$")
	public void admin_calls_it() throws Throwable {
		driver.findElement(By.xpath("//li[@class=\"nav-item active\"]")).click();
		driver.findElement(By.xpath("(//a[text()='View page'])[6]")).click();
	}

	@Then("^List of issued books are returned$")
	public void list_of_issued_books_are_returned() throws Throwable {
		System.out.println(driver.getTitle());
		driver.findElement(By.linkText("Logout")).click();
		Thread.sleep(3000);
		driver.close();
	}

}
