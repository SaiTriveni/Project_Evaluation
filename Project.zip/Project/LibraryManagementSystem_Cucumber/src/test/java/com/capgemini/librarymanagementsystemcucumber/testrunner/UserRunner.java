package com.capgemini.librarymanagementsystemcucumber.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "F:\\ProjectWorkspace\\librarymanagementsystemcucumber\\src\\test\\java\\com\\capgemini\\librarymanagementsystemcucumber\\feature\\Users.feature", 
glue = {"com.capgemini.librarymanagementsystemcucumber.stepdefination" },
        dryRun =false, monochrome = true)
public class UserRunner {

}
