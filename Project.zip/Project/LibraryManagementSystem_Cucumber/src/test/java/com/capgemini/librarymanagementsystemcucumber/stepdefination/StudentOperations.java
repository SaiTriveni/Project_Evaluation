package com.capgemini.librarymanagementsystemcucumber.stepdefination;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StudentOperations {
	WebDriver driver;
	static {

		System.setProperty("webdriver.chrome.driver",
				"F:\\ProjectWorkspace\\librarymanagementsystemcucumber\\src\\main\\resource\\driver1\\chromedriver.exe");
	}

	@Given("^user enter the URL$")
	public void user_enter_the_URL() throws Throwable {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(3000, TimeUnit.SECONDS);
		driver.get("http://localhost:4200/login");
	}

	@When("^User login with valid credentials$")
	public void user_login_with_valid_credentials() throws Throwable {
		driver.findElement(By.id("email")).sendKeys("anudeep.boyapati333@gmail.com");
		driver.findElement(By.id("password")).sendKeys("Anu@14321");
		driver.findElement(By.xpath("//button[text()='Login']")).click();
	}

	@Then("^User should navigate to login page$")
	public void user_should_navigate_to_login_page() throws Throwable {
		System.out.println(driver.getTitle());
	}

	@When("^User gave details (\\d+)$")
	public void user_gave_details(int arg1) throws Throwable {
		driver.findElement(By.linkText("User")).click();
		driver.findElement(By.linkText("View page")).click();
		driver.findElement(By.xpath("//tr[1]//td[6]//button[1]")).click();
	}

	@Then("^List of borrowed books is returned$")
	public void list_of_borrowed_books_is_returned() throws Throwable {
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		driver.close();
	}

	@When("^User gave details to return book (\\d+), (\\d+)$")
	public void user_gave_details_to_return_book(int arg1, int arg2) throws Throwable {
		driver.findElement(By.linkText("User")).click();
		driver.findElement(By.xpath("(//a[text()='View page'])[2]")).click();
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
	}

	@Then("^Book is returned$")
	public void book_is_returned() throws Throwable {
		System.out.println(driver.getTitle());
		Thread.sleep(3000);
		driver.close();
	}

}
