import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { LoginComponent } from './login/login.component';
import { AddBookComponent } from './add-book/add-book.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { AuthenticationComponent } from './authentication/authentication.component';
import { BookInfoComponent } from './book-info/book-info.component';
import { UpdateBookComponent } from './update-book/update-book.component';
import { StudentComponent } from './student/student.component';
import { BookFilterPipe } from './book-filter.pipe';
import { ShowRequestsComponent } from './show-requests/show-requests.component';
import { ShowUsersComponent } from './show-users/show-users.component';
import { IssuedBooksComponent } from './issued-books/issued-books.component';
import { RequestBookComponent } from './request-book/request-book.component';
import { ReturnBookComponent } from './return-book/return-book.component';
import { AboutComponent } from './about/about.component';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AdminComponent,
    LoginComponent,
    HeaderComponent,
    AuthenticationComponent,
    AddBookComponent,
    BookInfoComponent,
    UpdateBookComponent,
    StudentComponent,
    BookFilterPipe,
    ShowRequestsComponent,
    ShowUsersComponent,
    IssuedBooksComponent,
    RequestBookComponent,
    ReturnBookComponent,
    AboutComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
