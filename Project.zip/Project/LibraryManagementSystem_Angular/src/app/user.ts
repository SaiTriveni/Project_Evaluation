export class User {
    constructor(
        adminId: number,
        adminName: string,
        email: string,
        password: string

    ) { }
}