package com.capgemini.library_management_system_jdbc_corejava.dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;

import com.capgemini.library_management_system_jdbc_corejava.dto.AdminDto;
import com.capgemini.library_management_system_jdbc_corejava.dto.BookDto;
import com.capgemini.library_management_system_jdbc_corejava.dto.UserDto;
import com.capgemini.library_management_system_jdbc_corejava.exception.ErrorException;

/**
 * 
 * @author Sai Triveni This is an implementation class of AdminDao interface,
 *         and it implements all the methods of interface.
 *
 */
public class AdminDaoImplementation implements AdminDao {

	Connection connection = null;
	Statement statement = null;
	ResultSet resultset = null;
	PreparedStatement pStatement = null;
	boolean flag = false;

	/**
	 * This is a non-static method, and it takes care of registering Admin.
	 * 
	 * @param admin
	 * @return boolean
	 */
	public boolean register(AdminDto admin) {
		flag = false;
		try {

			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("query"));
			pStatement.setInt(1, admin.getAdminUserId());
			pStatement.setString(2, admin.getAdminUserName());
			pStatement.setString(3, admin.getAdminPassword());
			pStatement.setString(4, admin.getAdminEmail());
			pStatement.setString(5, admin.getAdminRole());
			int count = pStatement.executeUpdate();
			if (count != 0) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}

		return flag;
	}

	/**
	 * @author Sai Triveni This is non-static method and this serves the login
	 *         purpose.
	 * @param email
	 * @param password
	 * @return boolean
	 *
	 */
	public boolean auth(String email, String password) {

		flag = false;
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("select"));
			pStatement.setString(1, email);
			pStatement.setString(2, password);
			resultset = pStatement.executeQuery();
			if (resultset.next()) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return flag;

	}

	/**
	 * This is a non-static method and it helps to add books to the library based on
	 * the book details given by Admin.
	 * 
	 * @param book
	 * @return boolean
	 */
	public boolean addBook(BookDto book) {
		flag = false;
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("insertBook"));

			pStatement.setInt(1, book.getBookId());
			pStatement.setString(2, book.getBookTitle());
			pStatement.setString(3, book.getBookAuthor());
			pStatement.setString(4, book.getBookType());
			pStatement.setString(5, book.getBookPublisher());
			int res = pStatement.executeUpdate();
			if (res != 0) {
				flag = true;
			} else {
				flag = false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return flag;
	}

	/**
	 * This is a non-static method and it helps in searching books based on the
	 * given title passed during run time.
	 * 
	 * @param bookName
	 * @return ArrayList<bookDto>
	 */
	public LinkedList<BookDto> searchBookTitle(String bookName) {

		LinkedList<BookDto> list = new LinkedList<BookDto>();
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);
			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("searchTitle"));
			pStatement.setString(1, bookName);
			resultset = pStatement.executeQuery();
			while (resultset.next()) {
				BookDto bookDTO = new BookDto();
				bookDTO.setBookId(resultset.getInt("bookId"));
				bookDTO.setBookTitle(resultset.getString("bookTitle"));
				bookDTO.setBookAuthor(resultset.getString("bookAuthor"));
				bookDTO.setBookType(resultset.getString("bookType"));
				bookDTO.setBookPublisher(resultset.getString("bookPublisher"));
				list.add(bookDTO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return list;

	}

	/**
	 * This is a non-static method and it helps in searching books based on the
	 * given book Author passed during run time.
	 * 
	 * @param bookAuthor
	 * @return ArrayList<bookDto>
	 */
	public LinkedList<BookDto> searchBookAuthor(String bookAuthor) {
		LinkedList<BookDto> list = new LinkedList<BookDto>();
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("searchAuthor"));

			pStatement.setString(1, bookAuthor);
			resultset = pStatement.executeQuery();
			while (resultset.next()) {
				BookDto bookDTO = new BookDto();
				bookDTO.setBookId(resultset.getInt("bookId"));
				bookDTO.setBookTitle(resultset.getString("bookTitle"));
				bookDTO.setBookAuthor(resultset.getString("bookAuthor"));
				bookDTO.setBookType(resultset.getString("bookType"));
				bookDTO.setBookPublisher(resultset.getString("bookPublisher"));
				list.add(bookDTO);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return list;

	}

	/**
	 * This is a non-static method and it helps in searching books based on the
	 * given type passed during run time.
	 * 
	 * @param bookType
	 * @return ArrayList<bookDto>
	 */
	public LinkedList<BookDto> searchBookType(String bookType) {

		LinkedList<BookDto> list = new LinkedList<BookDto>();
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("searchType"));

			pStatement.setString(1, bookType);
			resultset = pStatement.executeQuery();
			while (resultset.next()) {
				BookDto bookDTO = new BookDto();
				bookDTO.setBookId(resultset.getInt("bookId"));
				bookDTO.setBookTitle(resultset.getString("bookTitle"));
				bookDTO.setBookAuthor(resultset.getString("bookAuthor"));
				bookDTO.setBookType(resultset.getString("bookType"));
				bookDTO.setBookPublisher(resultset.getString("bookPublisher"));
				list.add(bookDTO);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return list;

	}

	/**
	 * This is a non-static method and it updates the book title of a book which is
	 * given during run time.
	 * 
	 * @param bookId
	 * @param bookTitle
	 * @return boolean
	 * 
	 */
	public boolean updateBook(int bookId, String bookAuthor) {
		flag = false;
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("update"));

			pStatement.setString(1, bookAuthor);
			pStatement.setInt(2, bookId);
			int res = pStatement.executeUpdate();
			if (res != 0) {
				flag = true;
			} else {
				flag = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return flag;

	}

	/**
	 * This is a non-static method and it lists out all the book Id's of the books
	 * present in library till date.
	 * 
	 * @return LinkedList<Integer>
	 */
	public LinkedList<Integer> getBookIds() {
		LinkedList<Integer> list = new LinkedList<Integer>();
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("searchId"));

			resultset = pStatement.executeQuery();
			while (resultset.next()) {
				list.add(resultset.getInt("bookId"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return list;

	}

	/**
	 * This is a non-static method and this method when called up, lists out all the
	 * books present in the library with full information.
	 * 
	 * @return List<BookDto>
	 */
	public LinkedList<BookDto> getBooksInfo() {

		LinkedList<BookDto> list = new LinkedList<BookDto>();
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("displayAll"));

			resultset = pStatement.executeQuery();
			while (resultset.next()) {
				BookDto bookDTO = new BookDto();
				bookDTO.setBookId(resultset.getInt("bookId"));
				bookDTO.setBookTitle(resultset.getString("bookTitle"));
				bookDTO.setBookAuthor(resultset.getString("bookAuthor"));
				bookDTO.setBookType(resultset.getString("bookType"));
				bookDTO.setBookPublisher(resultset.getString("bookPublisher"));
				list.add(bookDTO);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return list;
	}

	/**
	 * This is a non-static method and this method is used to remove the books from
	 * the library based on the bookId given during run time.
	 * 
	 * @param bookId
	 * @return boolean
	 */
	public boolean removeBook(int bookId) {
		flag = false;
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("removeBook"));

			pStatement.setInt(1, bookId);
			int res = pStatement.executeUpdate();
			if (res != 0) {
				flag = true;
			} else {
				flag = false;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return flag;
	}

	/**
	 * This is a non-static method and it shows all the list of Users/Students who
	 * visit the library
	 * 
	 * @return List<UserDto?
	 */
	public List<String> showStudents() {
		LinkedList<String> list = new LinkedList<String>();
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("displayAllUsers"));

			resultset = pStatement.executeQuery();
			while (resultset.next()) {
				list.add(resultset.getString("userName"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return list;
	}

	/**
	 * This is a non-static method and it shows all the list of requests made by
	 * user to take a book in the library.
	 * 
	 * @return List<RequestDto?
	 */
	public LinkedList<Integer> showRequests() {
		LinkedList<Integer> list = new LinkedList<Integer>();
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("displayAllRequests"));

			resultset = pStatement.executeQuery();
			while (resultset.next()) {
				list.add(resultset.getInt("requestUserId"));
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return list;
	}

	/**
	 * This is a non-static method, it is used to issue the book to the User based
	 * on his/her request. In the process of issuing also,it validates the user, as
	 * the book can be given to user or not based on his previous book requests
	 * history.
	 * 
	 * @param user
	 * @param book
	 * @return boolean
	 */
	public boolean issueBook(int bookId, int userId) {
		String title = "";
		try {
			FileInputStream inputStream = new FileInputStream("db.properties");
			Properties properties = new Properties();
			properties.load(inputStream);

			Class.forName(properties.getProperty("path")).newInstance();
			// 2.Get the "DB connection" via Driver
			String dburl = properties.getProperty("dburl");
			connection = DriverManager.getConnection(dburl, properties);
			// 3.Issue the SQL query via connection
			pStatement = connection.prepareStatement(properties.getProperty("issueBook"));
			pStatement.setInt(1, bookId);
			resultset = pStatement.executeQuery();
			if (resultset.next()) {
				title = resultset.getString("bookTitle");
				PreparedStatement ps = connection.prepareStatement(properties.getProperty("insertIssueBook"));
				ps.setInt(1, resultset.getInt("bookId"));
				System.out.println(resultset.getInt("bookId"));
				ps.setString(2, resultset.getString("bookTitle"));
				ps.setString(3, resultset.getString("bookAuthor"));
				ps.setString(4, resultset.getString("bookType"));
				ps.setString(5, resultset.getString("bookPublisher"));
				int res = ps.executeUpdate();
				if (res != 0) {
					flag = true;
				} else {
					flag = false;
				}
			} else {
				throw new ErrorException("Book Not Found In Library");
			}
			PreparedStatement ps1 = connection.prepareStatement(properties.getProperty("insertRequestBook"));
			ps1.setInt(1, bookId);
			ps1.setInt(2, userId);
			ps1.setString(3, title);
			int res = ps1.executeUpdate();
			if (res == 0) {
				throw new ErrorException("insert into RequestBook is Failed");
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 5.close all the jdbc objects
			try {
				if (connection != null) {

					connection.close();
				}
				if (pStatement != null) {
					pStatement.close();
				}
				if (resultset != null) {
					resultset.close();
				}
			} catch (Exception e) {

				e.printStackTrace();
			}

		}
		return flag;
	}

	/**
	 * This is a non-static method and it plays a role to receive the book returned
	 * by the user.
	 * 
	 * @param user
	 * @param book
	 * @return boolean
	 */
	public boolean isBookReceived(UserDto student, BookDto book) {
		return false;
	}

}
