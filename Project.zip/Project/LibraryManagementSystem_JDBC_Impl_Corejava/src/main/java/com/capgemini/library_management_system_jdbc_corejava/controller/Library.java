package com.capgemini.library_management_system_jdbc_corejava.controller;
 
/**
 * 
 * @author Sai Triveni
 * This is a class, execution starts when we run this class only.
 */
public class Library {
	
	/**
	 * This is main method, execution starts from this method.
	 * @param args
	 */
	public static void main(String[] args) {
		Librarian librarian=new Librarian();
		librarian.start();
	} 
} 
