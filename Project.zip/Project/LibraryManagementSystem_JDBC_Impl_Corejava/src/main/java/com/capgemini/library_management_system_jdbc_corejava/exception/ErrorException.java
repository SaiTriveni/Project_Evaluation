package com.capgemini.library_management_system_jdbc_corejava.exception;


/**
 * 
 * @author Sai Triveni
 * This is a class of Exception which extends RuntimeException class and it has a constructor with arguments in it.
 *
 */
public class ErrorException extends RuntimeException{

public ErrorException(String msg) {
		
		super(msg);
	}

	
}
