package com.capgemini.library_management_system_jdbc_corejava.dao;

import java.util.LinkedList;

import com.capgemini.library_management_system_jdbc_corejava.dto.BookDto;
import com.capgemini.library_management_system_jdbc_corejava.dto.UserDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface, it has all the method signatures of User only which in turn helps in achieving 100% abstraction.
 *
 */
public interface UserDao {
	boolean register(UserDto std);
	LinkedList<BookDto> searchBookTitle(String bookName);
	LinkedList<BookDto> searchBookAuthor(String bookAuthor);
	LinkedList<BookDto> searchBookType(String bookType);
	LinkedList<Integer> getBookIds();
	LinkedList<BookDto> getBooksInfo();
	boolean requestBook(int bookId,int userId);
	boolean returnBook(int bookId,int userId);
	
	

}
