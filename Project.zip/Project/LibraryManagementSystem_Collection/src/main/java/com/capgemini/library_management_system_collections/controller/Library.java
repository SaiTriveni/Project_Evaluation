package com.capgemini.library_management_system_collections.controller;

import com.capgemini.library_management_system_collections.database.Database;


/**
 * 
 * @author Sai Triveni
 * This is a class, execution starts from here.
 */
public class Library {
	
	/**
	 * This is main method, execution starts from this method.
	 * addToDatabase() method is called to add sample data into collections.
	 * @param args
	 */
	public static void main(String[] args) {
		Database.addToDatabase();
		Librarian librarian=new Librarian();
		librarian.start();
	} 
} 
