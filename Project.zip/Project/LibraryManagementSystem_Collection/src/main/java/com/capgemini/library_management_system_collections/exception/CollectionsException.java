package com.capgemini.library_management_system_collections.exception;

/**
 * 
 * @author Sai Triveni
 * This is a class of Exception which extends RuntimeException class and it has a constructor with arguments in it.
 *
 */
public class CollectionsException extends RuntimeException{

	public CollectionsException(String msg) {
		super(msg);
	}
}
