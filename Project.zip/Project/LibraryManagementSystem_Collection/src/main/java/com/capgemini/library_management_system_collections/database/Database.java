package com.capgemini.library_management_system_collections.database;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.library_management_system_collections.dto.AdminDto;
import com.capgemini.library_management_system_collections.dto.BookDto;
import com.capgemini.library_management_system_collections.dto.RequestDto;
import com.capgemini.library_management_system_collections.dto.UserDto;

/**
 * 
 * @author Sai Triveni
 * This is a class and its purpose is to have the collections admin,user,books and requests made by user.
 * This uses ArrayList concept.
 */
public class Database {
	
	public static final List<AdminDto> ADMINS= new ArrayList<AdminDto>();
	public static final List<UserDto> USERS= new ArrayList<UserDto>();
	public static final List<BookDto> BOOKS= new ArrayList<BookDto>();
	public static final List<RequestDto> REQUESTS= new ArrayList<RequestDto>();
	
	/**
	 * This is a static method and it is used the sample data into collections when the main method is executed.
	 */
public static void addToDatabase() {
		
		ADMINS.add(new AdminDto(111111,"Sai Triveni","sai@gmail.com","Sai@160498"));
		
		
		BOOKS.add(new BookDto(123456,"Java","Mr.Sunil","Education","AKMPublishers"));
		BOOKS.add(new BookDto(123457,"Jdbc","Mr.Mahesh","Education","AKMPublishers"));
		BOOKS.add(new BookDto(123458,"Sequel","Mr.Dinesh","Education","SAPPublishers"));
		BOOKS.add(new BookDto(123459,"FullStackDevelopment","Mr.Sunil","Technical","SAPPublishers"));
		
		USERS.add(new UserDto(222222,"Sai","Sai@1234","sai@gmail.com",3));
		USERS.add(new UserDto(333333,"Akhil","Akhil@123","akhil@gmail.com",2));
		USERS.add(new UserDto(444444,"Junnu","Junnu@123","junnu@gmail.com",3));
}
	
	}
