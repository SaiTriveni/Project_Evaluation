package com.capgemini.library_management_system_collections.dao;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.capgemini.library_management_system_collections.dto.AdminDto;
import com.capgemini.library_management_system_collections.dto.BookDto;
import com.capgemini.library_management_system_collections.dto.RequestDto;
import com.capgemini.library_management_system_collections.dto.UserDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface, it has all the method signatures of Admin only which in turn helps in achieving 100% abstraction.
 * This is an example of achieving 100% abstraction.
 *
 */
public interface AdminDao {
	
	boolean register(AdminDto admin);
	boolean auth(String email,String password);
	boolean addBook(BookDto book);
	ArrayList<BookDto> searchBookTitle(String bookTitle);
	ArrayList<BookDto> searchBookAuthor(String bookAuthor);
	ArrayList<BookDto> searchBookType(String bookType);
	boolean updateBook(int bookId,String title);
	boolean removeBook(int bookId);
	LinkedList<Integer> getBookIds();
	List<BookDto> getBooksInfo();
	
	List<UserDto> showStudents();
	List<RequestDto> showRequests();
	boolean bookIssue(UserDto student,BookDto book);
	boolean isBookReceived(UserDto student,BookDto book);
	
	

}
