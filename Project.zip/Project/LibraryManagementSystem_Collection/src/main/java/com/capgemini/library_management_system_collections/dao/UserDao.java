package com.capgemini.library_management_system_collections.dao;

import java.util.ArrayList;
import java.util.List;

import com.capgemini.library_management_system_collections.dto.BookDto;
import com.capgemini.library_management_system_collections.dto.RequestDto;
import com.capgemini.library_management_system_collections.dto.UserDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface, it has all the method signatures of User only which in turn helps in achieving 100% abstraction.
 * This is an example of achieving 100% abstraction.
 */
public interface UserDao {
	boolean register(UserDto std);
	boolean auth(String email,String password);
	ArrayList<BookDto> searchBookTitle(String bookName);
	ArrayList<BookDto> searchBookAuthor(String bookAuthor);
	ArrayList<BookDto> searchBookType(String bookType);
	ArrayList<Integer> getBookIds();
	List<BookDto> getBooksInfo();
	RequestDto requestBook(UserDto student, BookDto book);
	RequestDto returnBook(UserDto student, BookDto book);
	
	

}
