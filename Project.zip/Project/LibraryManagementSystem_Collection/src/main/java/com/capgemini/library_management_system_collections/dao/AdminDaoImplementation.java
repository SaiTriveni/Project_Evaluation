package com.capgemini.library_management_system_collections.dao;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import com.capgemini.library_management_system_collections.database.Database;
import com.capgemini.library_management_system_collections.dto.AdminDto;
import com.capgemini.library_management_system_collections.dto.BookDto;
import com.capgemini.library_management_system_collections.dto.RequestDto;
import com.capgemini.library_management_system_collections.dto.UserDto;
import com.capgemini.library_management_system_collections.exception.CollectionsException;

/**
 * 
 * @author Sai Triveni
 * This is an implementation class of AdminDao interface, and it implements all the methods of interface.
 *
 */
public class AdminDaoImplementation implements AdminDao {

	/**
	 * This is a non-static method, and it takes care of registering Admin.
	 * @param admin
	 * @return boolean
	 */
	public boolean register(AdminDto admin) {

		for(AdminDto adm : Database.ADMINS) {
			if(adm.getAdminEmail().equals(admin.getAdminEmail())) {
				return false;
			}
		}
		Database.ADMINS.add(admin);
		return true;
	}

	/**
	 * This is non-static method and this serves the login purpose.
	 * @param email
	 * @param password
	 * @return boolean
	 *
	 */
	public boolean auth(String email, String password) {
		
		boolean flag = false;

		for(AdminDto adm : Database.ADMINS) {
			if(adm.getAdminEmail().equals(email) && adm.getAdminPassword().equals(password)) {
				flag = true;
			}
			else if(adm.getAdminEmail().equals(email) && !adm.getAdminPassword().equals(password)) {
				System.err.println("Password Incorrect");
				flag = false;
			}
			else {
				flag = false;
			}
		}
		return flag;
		}


	/**
	 * This is a non-static method and it helps to add books to the library based on the book details given by Admin.
	 * @param book
	 * @return boolean 
	 */
	public boolean addBook(BookDto book) {
		for(BookDto bookDto : Database.BOOKS) {
			if(bookDto.getBookId() == book.getBookId()  ) {
				return false;
			}
		}
		Database.BOOKS.add(book);
		return true;
	}

	/**
	 * This is a non-static method and it helps in searching books based on the given title passed during run time.
	 * @param bookName
	 * @return ArrayList<bookDto>
	 */
	public ArrayList<BookDto> searchBookTitle(String bookName) {

		ArrayList<BookDto> searchList=new ArrayList<BookDto>();
		for(int i=0;i<=Database.BOOKS.size()-1;i++)
		{
			BookDto retrievedBook=Database.BOOKS.get(i);
			String retrievedBookName=retrievedBook.getBookTitle();
			if(bookName.equals(retrievedBookName))
			{
				searchList.add(retrievedBook);	
				return searchList;	
			}
		}
		if(searchList.size()==0)
		{
			throw new CollectionsException("Book is Not Found");
		}
		else
		{
			return searchList;
		}		

	}

	/**
	 * This is a non-static method and it helps in searching books based on the given book Author passed during run time.
	 * @param bookAuthor
	 * @return ArrayList<bookDto>
	 */
	public ArrayList<BookDto> searchBookAuthor(String bookAuthor) {

		ArrayList<BookDto> searchList=new ArrayList<BookDto>();
		for(int i=0;i<=Database.BOOKS.size()-1;i++)
		{
			BookDto retrievedBook=Database.BOOKS.get(i);
			String retrievedBookAuthor=retrievedBook.getBookAuthor();
			if(bookAuthor.equals(retrievedBookAuthor))
			{
				searchList.add(retrievedBook);	
			}
		}
		if(searchList.size()==0)
		{
			throw new CollectionsException("Book is Not Found");
		}
		else
		{
			return searchList;
		}	
		
	}

	/**
	 * This is a non-static method and it helps in searching books based on the given type passed during run time.
	 * @param bookType
	 * @return ArrayList<bookDto>
	 */
	public ArrayList<BookDto> searchBookType(String bookType) {
		
		ArrayList<BookDto> searchList=new ArrayList<BookDto>();
		for(int i=0;i<=Database.BOOKS.size()-1;i++)
		{
			BookDto retrievedBook=Database.BOOKS.get(i);
			String retrievedBookType=retrievedBook.getBookType();
			if(bookType.equals(retrievedBookType))
			{
				searchList.add(retrievedBook);	
			}
		}
		if(searchList.size()==0)
		{
			throw new CollectionsException("Book is Not Found");
		}
		else
		{
			return searchList;
		}	
		
	}

	/**
	 * This is a non-static method and it updates the book title of a book which is given during run time.
	 * @param bookId
	 * @param bookTitle
	 * @return boolean
	 * 
	 */
	public boolean updateBook(int bookId,String title) {

		boolean status=false;
		for(int i=0;i<=Database.BOOKS.size()-1;i++)
		{
			BookDto retrievedBook=Database.BOOKS.get(i);
			int retrievedId=retrievedBook.getBookId();
			if(bookId==retrievedId)
			{
				retrievedBook.setBookTitle(title);
				status = true;
			}
			else {
				status = false;
			}
		}
		return status;
	}

	/**
	 * This is a non-static method and it lists out all the book Id's of the books present in library till date.
	 * @return LinkedList<Integer?
	 */
	public LinkedList<Integer> getBookIds() {
		LinkedList<Integer> idList=new LinkedList<Integer>();
		for(int i=0;i<=Database.BOOKS.size()-1;i++)
		{
			BookDto retrievedBook=Database.BOOKS.get(i);
			int retrievedBookId=retrievedBook.getBookId();
			idList.add(retrievedBookId);
		}
		return idList;
	}

	/**
	 * This is a non-static method and this method when called up, lists out all the books present in the library with full information.
	 * @return List<BookDto>
	 */
	public List<BookDto> getBooksInfo() {
		
		return Database.BOOKS;
	}

	/**
	 * This is a non-static method and this method is used to remove the books from the library based on the bookId given during run time.
	 * @param bookId
	 * @return boolean
	 */
	public boolean removeBook(int bookId) {
		boolean status=false;
		for(int i=0;i<=Database.BOOKS.size()-1;i++)
		{
			BookDto retrievedBook=Database.BOOKS.get(i);
			int retrievedId=retrievedBook.getBookId();
			if(bookId==retrievedId)
			{
				status=true;
				Database.BOOKS.remove(i);
				
			}
		}
		return status;
	}

	/**
	 * This is a non-static method and it shows all the list of Users/Students who visit the library
	 * @return List<UserDto>
	 */
	public List<UserDto> showStudents() {
		List<UserDto> show = new LinkedList<UserDto>();

		for (UserDto info : Database.USERS) {
			info.getUserId();
			info.getUserName();
			info.getUserEmail();
			info.getUserBooksBorrowed();
			show.add(info);
		}
		return show;
	}
		
	/**
	 * This is a non-static method and it shows all the list of requests made by user to take a book in the library.
	 * @return List<RequestDto>
	 */
	public List<RequestDto> showRequests() {
		List<RequestDto> show = new LinkedList<RequestDto>();
		for (RequestDto requestInfo : Database.REQUESTS) {
			requestInfo.getBookInfo();
			requestInfo.getStudentInfo();
			requestInfo.isIssued();
			requestInfo.isReturned();
			show.add(requestInfo);
		}
		return show;
	}
		

	/**
	 * This is a non-static method, it is used to issue the book to the User based on his/her request.
	 * In the process of issuing also,it validates the user, as the book can be given to user or not based on his previous book requests history.
	 * @param user
	 * @param book
	 * @return boolean
	 */
	public boolean bookIssue(UserDto student, BookDto book) {
		boolean isValid = false;

		RequestDto requestInfo = new RequestDto();

		int noOfBooksBorrowed = student.getUserBooksBorrowed();
		for (RequestDto info : Database.REQUESTS) {
			if (info.getStudentInfo().getUserId() == student.getUserId()) {
				if (info.getBookInfo().getBookId() == book.getBookId()) {
					requestInfo = info;
					isValid = true;
				}
			}
		}
		if (isValid)
		{
			for (BookDto info2 : Database.BOOKS) {
				if (info2.getBookId() == book.getBookId()) {
					book = info2;
				}
			}
			for (UserDto studentInfo : Database.USERS) {
				if (studentInfo.getUserId() == student.getUserId()) {
					student = studentInfo;
					noOfBooksBorrowed = student.getUserBooksBorrowed();
				}
			}
			if (noOfBooksBorrowed < 3) {
				
				boolean isRemoved = Database.BOOKS.remove(book);
				if (isRemoved) {
					
					noOfBooksBorrowed++;
					System.out.println(noOfBooksBorrowed);
					student.setUserBooksBorrowed(noOfBooksBorrowed);
					requestInfo.setIssued(true);
					return true;
				} else {
					throw new CollectionsException("Book can't be borrowed");
				}

			} else {
				throw new CollectionsException("Student Exceeds maximum limit");
			}

		} else {
			throw new CollectionsException("Book data or Student data is incorrect");

		}
	}
		
	/**
	 * This is a non-static method and it plays a role to receive the book returned by the user.
	 * @param user
	 * @param book
	 * @return boolean
	 */
	public boolean isBookReceived(UserDto student, BookDto book) {
		boolean isValid = false;
		RequestDto requestInfo1 = new RequestDto();
		for (RequestDto requestInfo : Database.REQUESTS) {

			if (requestInfo.getBookInfo().getBookId() == book.getBookId()
					&& requestInfo.getStudentInfo().getUserId() == student.getUserId() && requestInfo.isReturned() == true) {
				isValid = true;
				requestInfo1 = requestInfo;
			}
		}
		if (isValid) {
			
			book.setBookAuthor(requestInfo1.getBookInfo().getBookAuthor());
			book.setBookTitle(requestInfo1.getBookInfo().getBookTitle());
			Database.BOOKS.add(book);
			Database.REQUESTS.remove(requestInfo1);
			for (UserDto userInfo2 : Database.USERS) {
				if (userInfo2.getUserId() == student.getUserId()) {
					student = userInfo2;
				}

			}
			int noOfBooksBorrowed = student.getUserBooksBorrowed();
			noOfBooksBorrowed--;
			student.setUserBooksBorrowed(noOfBooksBorrowed);
			return true;
		}
		return false;
	}
}
