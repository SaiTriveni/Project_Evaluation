package com.capgemini.library_management_system_collections.factory;

import com.capgemini.library_management_system_collections.dao.AdminDao;
import com.capgemini.library_management_system_collections.dao.AdminDaoImplementation;
import com.capgemini.library_management_system_collections.dao.UserDao;
import com.capgemini.library_management_system_collections.dao.UserDaoImplementation;
import com.capgemini.library_management_system_collections.service.AdminService;
import com.capgemini.library_management_system_collections.service.AdminServiceImplementation;
import com.capgemini.library_management_system_collections.service.UserService;
import com.capgemini.library_management_system_collections.service.UserServiceImplementation;

/**
 * 
 * @author Sai Triveni
 * This is a class and it calls the services of admin and user operations.
 *
 */
public class BookFactory {
	
	public static AdminDao getAdminDao() {
		return new AdminDaoImplementation();
		
	}
	
	public static AdminService getAdminService() {
		return new AdminServiceImplementation();
	}
	
	public static UserDao getStudentDAO() {
		
		return new UserDaoImplementation();
	}
	
	public static UserService getStudentService() {
		return new UserServiceImplementation();
	}
	

}
