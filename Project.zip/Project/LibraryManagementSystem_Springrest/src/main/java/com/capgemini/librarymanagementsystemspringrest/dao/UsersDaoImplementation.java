package com.capgemini.librarymanagementsystemspringrest.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.UsersDto;
import com.capgemini.librarymanagementsystemspringrest.exception.LMSException;

/**
 * @author sai triveni This is an implementation class of UserDao interface, and
 *         it implements all the methods of interface.
 *
 */
@Repository
public class UsersDaoImplementation implements UsersDao {

	EntityManager manager = null;
	EntityTransaction transaction = null;
	int noOfBooks;

	@PersistenceUnit
	private EntityManagerFactory factory;

	/**
	 * This is a non-static method, and it takes care of registering User.
	 * 
	 * @param user
	 * @return boolean
	 */
	@Override
	public boolean register(UsersDto user) {
		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			manager.persist(user);
			transaction.commit();
			return true;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	/**
	 * This is non-static method and this serves the login purpose.
	 * 
	 * @param email
	 * @param password
	 * @return boolean
	 *
	 */
	@Override
	public UsersDto login(String email, String password) {
		try {

			UsersDto bean = getUser(email);
			if (bean.getEmail() != null && bean.getEmail().equals(email) && bean.getPassword().equals(password)) {
				return bean;
			} else {

				return null;
			}

		} catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}
	}

	/**
	 * This method is used to get user details based on email.
	 * 
	 * @param email
	 * @return UserDto
	 */
	public UsersDto getUser(String email) {
		manager = factory.createEntityManager();
		String jpql = "select u from UsersDto u where u.email=:email";
		TypedQuery<UsersDto> query = manager.createQuery(jpql, UsersDto.class);
		query.setParameter("email", email);
		UsersDto bean = query.getSingleResult();
		return bean;
	}

	/**
	 * This is a non-static method and it helps in searching books based on the
	 * given bookId passed during run time.
	 * 
	 * @param bookId
	 * @return List<bookDto>
	 */
	@Override
	public List<BookDto> searchBookById(int bookId) {
		try {
			manager = factory.createEntityManager();
			String jpql = "select b from BookDto b where b.bId=:bId";
			TypedQuery<BookDto> query = manager.createQuery(jpql, BookDto.class);
			query.setParameter("bId", bookId);
			List<BookDto> recordList = query.getResultList();
			return recordList;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}
	}

	/**
	 * This is a non-static method and it helps in searching books based on the
	 * given title passed during run time.
	 * 
	 * @param bookName
	 * @return List<bookDto>
	 */
	@Override
	public List<BookDto> searchBookByTitle(String bookName) {
		try {
			manager = factory.createEntityManager();
			String jpql = "select b from BookDto b where b.bookName=:bookName";
			TypedQuery<BookDto> query = manager.createQuery(jpql, BookDto.class);
			query.setParameter("bookName", bookName);
			List<BookDto> recordList = query.getResultList();
			return recordList;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}
	}

	/**
	 * This is a non-static method and it helps in searching books based on the
	 * given book author passed during run time.
	 * 
	 * @param bookAuthor
	 * @return List<bookDto>
	 */
	@Override
	public List<BookDto> searchBookByAuthor(String bookAuthor) {
		try {
			manager = factory.createEntityManager();
			String jpql = "select b from BookDto b where b.author=:author";
			TypedQuery<BookDto> query = manager.createQuery(jpql, BookDto.class);
			query.setParameter("author", bookAuthor);
			List<BookDto> recordList = query.getResultList();
			return recordList;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return null;
		}
	}

	/**
	 * This is a non-static method and this method when called up, lists out all the
	 * books present in the library with full information.
	 * 
	 * @return List<BookDto>
	 */
	@Override
	public List<BookDto> getBooksInfo() {
		manager = factory.createEntityManager();
		String jpql = "select b from BookDto b";
		TypedQuery<BookDto> query = manager.createQuery(jpql, BookDto.class);
		List<BookDto> recordList = query.getResultList();
		return recordList;
	}

	/**
	 * This method is used to update password
	 * 
	 * @param id
	 * @param password
	 * @param newPassword
	 * @param role
	 * @return boolean
	 */
	@Override
	public boolean updatePassword(int id, String currentPassword, String newPassword, String role) {
		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			String jpql = "select u from UsersDto u where u.uId=:uId and u.role=:role and u.password=:password";
			TypedQuery<UsersDto> query = manager.createQuery(jpql, UsersDto.class);
			query.setParameter("uId", id);
			query.setParameter("role", role);
			query.setParameter("password", currentPassword);
			UsersDto rs = query.getSingleResult();
			if (rs != null) {
				UsersDto record = manager.find(UsersDto.class, id);
				record.setPassword(newPassword);
				transaction.commit();
				return true;
			} else {
				throw new LMSException("User doesnot exist,kindly register and try again!");
			}

		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

}
