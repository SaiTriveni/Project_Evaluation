package com.capgemini.librarymanagementsystemspringrest.controller;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.capgemini.librarymanagementsystemspringrest.dto.LmsResponse;
import com.capgemini.librarymanagementsystemspringrest.exception.LMSException;

/**
 * 
 * @author Sai Triveni
 * This class has the exceptionHandler which takes care of the errors and error messages.
 *
 */
@RestControllerAdvice
public class MyRestControllerAdvice {

	/**
	 * This is a non-static method where lmsException has been passed.
	 * @param lmsException
	 * @return LmsResponse
	 */
	@ExceptionHandler
	public LmsResponse myExceptionHandler(LMSException lmsException) {
		LmsResponse response = new LmsResponse();
		response.setError(true);
		response.setMessage(lmsException.getMessage());
		return response;
	}
}
