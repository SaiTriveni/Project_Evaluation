package com.capgemini.librarymanagementsystemspringrest.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

/**
 * 
 * @author Sai Triveni
 * This class takes care of errors and messages and objects of other classes which results in giving a response.
 *
 */
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class LmsResponse {

	private boolean error;
	private String message;

	private BookDto bookInfo;
	private List<BookDto> booksInfo;
	
	private UsersDto userInfo;
	private List<UsersDto> usersInfo;

	private BookIssueDetailsDto bookIssueInfo;
	private List<BookIssueDetailsDto> issueInfo;
	
	private BooksBorrowedDto borrowedBooksInfo;
	private List<BooksBorrowedDto> borrowedBooks;
	
	private RequestDto requestInfo;
	private List<RequestDto> requests;
}
