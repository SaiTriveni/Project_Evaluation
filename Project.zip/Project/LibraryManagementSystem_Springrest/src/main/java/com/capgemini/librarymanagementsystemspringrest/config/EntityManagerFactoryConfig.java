package com.capgemini.librarymanagementsystemspringrest.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

/**
 * 
 * @author Sai Triveni
 * This is a class and it refers to the configuration file. It is named as TestPersistence.
 *
 */
@Configuration
public class EntityManagerFactoryConfig {

	/**
	 * This is a non-static method and persistenceUnitName is given through here where all the database configurations are given.
	 * @Bean is an other way to create an object.
	 * @return
	 */
	@Bean
	public LocalContainerEntityManagerFactoryBean getEntityManager() {
		LocalContainerEntityManagerFactoryBean factoryBean = new 
				LocalContainerEntityManagerFactoryBean();
		factoryBean.setPersistenceUnitName("TestPersistence");

		return factoryBean;
	}
}
