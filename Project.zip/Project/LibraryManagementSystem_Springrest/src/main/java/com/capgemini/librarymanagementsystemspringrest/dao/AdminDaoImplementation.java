package com.capgemini.librarymanagementsystemspringrest.dao;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BookIssueDetailsDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BooksBorrowedDto;
import com.capgemini.librarymanagementsystemspringrest.dto.RequestDto;
import com.capgemini.librarymanagementsystemspringrest.dto.UsersDto;
import com.capgemini.librarymanagementsystemspringrest.exception.LMSException;

/**
 * 
 * @author Sai Triveni
 * This is an implementation class of AdminDao interface, and it implements all the methods of interface.
 *
 */
@Repository
public class AdminDaoImplementation implements AdminDao{

	EntityManager manager = null;
	EntityTransaction transaction = null;
	int noOfBooks;

	@PersistenceUnit
	private EntityManagerFactory factory;

	/**
	 * This is a non-static method and it helps to add books to the library based on the book details given by Admin.
	 * @param book
	 * @return boolean 
	 */
	@Override
	public boolean addBook(BookDto book) {
		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			manager.persist(book);
			transaction.commit();
			return true;
		}catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		}
	}

	/**
	 * This is a non-static method and this method is used to remove the books from the library based on the bookId given during run time.
	 * @param bookId
	 * @return boolean
	 */
	@Override
	public boolean removeBook(int bookId) {
		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			BookDto record = manager.find(BookDto.class,bookId);
			manager.remove(record);
			transaction.commit();
			return true;
		} catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		} 
	}

	/**
	 * This is a non-static method and it updates the book title of a book which is given during run time.
	 * @param bookId
	 * @param bookTitle
	 * @return boolean
	 * 
	 */
	@Override
	public boolean updateBook(BookDto book) {
		boolean isUpdated = false;
		manager = factory.createEntityManager();
		BookDto existing = manager.find(BookDto.class, book.getBId());
		if(existing != null) {
			try{
				transaction = manager.getTransaction();
				transaction.begin();

				existing.setBookName(book.getBookName());
				existing.setAuthor(book.getAuthor());
				existing.setCategory(book.getCategory());
				existing.setPublisher(book.getPublisher());

				transaction.commit();
				isUpdated = true;
			}catch (Exception e) {
				System.err.println(e.getMessage());
			}

		}
		return isUpdated;
	}



	/**
	 * This is a non-static method and it shows all the list of requests made by user to take a book in the library.
	 * @return List<RequestDto?
	 */
	@Override
	public List<RequestDto> showRequests() {
		manager = factory.createEntityManager();
		String jpql = "select r from RequestDto r";
		TypedQuery<RequestDto> query = manager.createQuery(jpql,RequestDto.class);
		List<RequestDto> recordList = query.getResultList();
		return recordList;
	}

	/**
	 * This method lists out all the issuedBooks details
	 * @return List<BookIssueDetailsDto>
	 */
	@Override
	public List<BookIssueDetailsDto> showIssuedBooks() {
		manager = factory.createEntityManager();
		String jpql = "select b from BookIssueDetailsDto b";
		TypedQuery<BookIssueDetailsDto> query = manager.createQuery(jpql,BookIssueDetailsDto.class);
		List<BookIssueDetailsDto> recordList = query.getResultList();
		return recordList;
	}

	/**
	 * This is a non-static method and it shows all the list of Users/Students who visit the library
	 * @return List<UserDto>
	 */
	@Override
	public List<UsersDto> showUsers() {
		manager = factory.createEntityManager();
		String jpql = "select u from UsersDto u";
		TypedQuery<UsersDto> query = manager.createQuery(jpql,UsersDto.class);
		List<UsersDto> recordList = query.getResultList();
		return recordList;
	}

	/**
	 * This method is used to cancel the request placed by user to get a book
	 * @param userId
	 * @param bookId
	 * @return boolean
	 */
	@Override
	public boolean cancelRequest(int userId, int bookId) {	
		try {

			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			transaction.begin();
			String jpql = "select r from RequestDto r where r.bId=:bId and r.uId=:uId";
			Query query4 = manager.createQuery(jpql);
			query4.setParameter("bId", bookId);
			query4.setParameter("uId", userId);
			RequestDto rdb = (RequestDto) query4.getSingleResult();
			manager.remove(rdb);
			transaction.commit();

			return true;

		}catch (Exception e) {
			System.out.println(e.getMessage());
			return false;
		}
	}


	/**
	 * This is a non-static method, it is used to issue the book to the User based on his/her request.
	 * In the process of issuing also,it validates the user, as the book can be given to user or not based on his previous book requests history.
	 * @param userId
	 * @param bookId
	 * @return boolean
	 */
	@Override 
	public boolean issueBook(int bookId, int userId) {
		try {
			manager = factory.createEntityManager();
			transaction = manager.getTransaction();
			String jpql = "select b from BookDto b where b.bId=:bId";
			TypedQuery<BookDto> query = manager.createQuery(jpql,BookDto.class);
			query.setParameter("bId", bookId);
			BookDto rs = query.getSingleResult();
			if(rs != null) {
				String jpql1 = "select r from RequestDto r where r.uId=:uId and r.bId=:bId";
				TypedQuery<RequestDto> query1 = manager.createQuery(jpql1,RequestDto.class);
				query1.setParameter("uId", userId);
				query1.setParameter("bId", bookId);
				List<RequestDto> rs1 = query1.getResultList();
				if(!rs1.isEmpty() && rs1 != null) {
					transaction.begin();
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); 
					Calendar cal = Calendar.getInstance();
					String issueDate = sdf.format(cal.getTime());
					cal.add(Calendar.DAY_OF_MONTH, 7);
					String returnDate = sdf.format(cal.getTime());
					BookIssueDetailsDto issueBook = new BookIssueDetailsDto();
					issueBook.setUId(userId);
					issueBook.setBId(bookId);
					issueBook.setIssueDate(java.sql.Date.valueOf(issueDate));
					issueBook.setReturnDate(java.sql.Date.valueOf(returnDate));
					manager.persist(issueBook);
					transaction.commit();
					if(!rs1.isEmpty() && rs1 != null) {
						transaction.begin();
						Query bookName = manager.createQuery("select b.bookName from BookDto b where b.bId=:bId");
						bookName.setParameter("bId", bookId);
						@SuppressWarnings("rawtypes")
						List book = bookName.getResultList();
						BooksBorrowedDto borrowedBooks = new BooksBorrowedDto();
						borrowedBooks.setUId(userId);
						borrowedBooks.setBId(bookId);
						borrowedBooks.setBookName(book.get(0).toString());
						manager.persist(borrowedBooks);
						transaction.commit();

						transaction.begin();
						String jpql4 = "select r from RequestDto r where r.bId=:bId and r.uId=:uId";
						Query query4 = manager.createQuery(jpql4);
						query4.setParameter("bId", bookId);
						query4.setParameter("uId", userId);
						RequestDto rdb = (RequestDto) query4.getSingleResult();
						manager.remove(rdb);
						transaction.commit();


						return true;
					}else {
						throw new LMSException("Book has not been issued successfully");
					}
				}else {
					throw new LMSException("This user has not placed any request to borrow a book from the library!");
				}
			}else {
				throw new LMSException("Books with "+bookId+" bookId are not present in the library!");
			}
		}catch (Exception e) {
			System.err.println(e.getMessage());
			return false;
		}
	}


	/**
	 * This method returns all the details of the books issued and books present in the library
	 * @param userId
	 * @return List<Integer>
	 */
	@SuppressWarnings("unused")
	@Override
	public List<Integer> bookIssuedDetails(int userId) {
		int count=0;
		manager = factory.createEntityManager();
		String jpql = "select b from BookIssueDetailsDto b";
		TypedQuery<BookIssueDetailsDto> query = manager.createQuery(jpql,BookIssueDetailsDto.class);
		List<BookIssueDetailsDto> recordList = query.getResultList();
		for(BookIssueDetailsDto p : recordList) {
			noOfBooks = count++;
		}
		LinkedList<Integer> list = new LinkedList<Integer>();
		list.add(noOfBooks);
		return list;
	}

}
