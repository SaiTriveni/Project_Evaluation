package com.capgemini.librarymanagementsystemspringrest.dao;

import java.util.List;

import com.capgemini.librarymanagementsystemspringrest.dto.BooksBorrowedDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface which takes of main operations of students i.e., request and return book
 *
 */
public interface StudentDao {
	List<BooksBorrowedDto> borrowedBook(int userId);
	boolean requestBook(int userId, int bookId);
	boolean returnBook(int bookId,int userId);
	
}
