package com.capgemini.librarymanagementsystemspringrest.service;

import java.util.List;

import com.capgemini.librarymanagementsystemspringrest.dto.BooksBorrowedDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface of Student related operations, this gets called after factory object is created.
 *
 */
public interface StudentService {
	List<BooksBorrowedDto> borrowedBook(int uId);
	boolean requestBook(int userId, int bookId);
	boolean returnBook(int bookId,int userId);
	
}
