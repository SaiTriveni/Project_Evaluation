package com.capgemini.librarymanagementsystemspringrest.service;

import java.util.List;

import com.capgemini.librarymanagementsystemspringrest.dto.BookDto;
import com.capgemini.librarymanagementsystemspringrest.dto.BookIssueDetailsDto;
import com.capgemini.librarymanagementsystemspringrest.dto.RequestDto;
import com.capgemini.librarymanagementsystemspringrest.dto.UsersDto;

/**
 * 
 * @author Sai Triveni
 * This is an interface of Admin related operations, this gets called after factory object is created.
 *
 */
public interface AdminService {
	boolean addBook(BookDto book);
	boolean removeBook(int bookId);
	boolean updateBook(BookDto book);
	List<RequestDto> showRequests();
	List<BookIssueDetailsDto> showIssuedBooks();
	List<UsersDto> showUsers();
	boolean issueBook(int bookId,int userId);
	List<Integer> bookIssuedDetails(int userId);
	boolean cancelRequest(int userId,int bookId);

}
