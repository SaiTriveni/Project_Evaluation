/*
SQLyog - Free MySQL GUI v5.02
Host - 5.5.27 : Database - librarymanagementsystemspring
*********************************************************************
Server version : 5.5.27
*/


create database if not exists `librarymanagementsystemspring`;

USE `librarymanagementsystemspring`;

/*Table structure for table `book_issue_details` */

DROP TABLE IF EXISTS `book_issue_details`;

CREATE TABLE `book_issue_details` (
  `id` int(11) NOT NULL,
  `bId` int(11) DEFAULT NULL,
  `issueDate` date DEFAULT NULL,
  `returnDate` date DEFAULT NULL,
  `uId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `book_issue_details` */

insert into `book_issue_details` values 
(1102,5702,'2020-06-07','2020-06-14',105302);

/*Table structure for table `bookbean` */

DROP TABLE IF EXISTS `bookbean`;

CREATE TABLE `bookbean` (
  `bId` int(11) NOT NULL,
  `author` varchar(255) DEFAULT NULL,
  `bookName` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `publisher` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`bId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `bookbean` */

insert into `bookbean` values 
(5702,'H c varma ','Java Database Connectivity','Database','Mahesh'),
(5802,'Bhargav','DLD','Electronics','Phani'),
(5902,'Bhargav','DLD','Electronics','Phani');

/*Table structure for table `borrowed_books` */

DROP TABLE IF EXISTS `borrowed_books`;

CREATE TABLE `borrowed_books` (
  `id` int(11) NOT NULL,
  `bId` int(11) DEFAULT NULL,
  `bookName` varchar(255) DEFAULT NULL,
  `uId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `borrowed_books` */

insert into `borrowed_books` values 
(1102,5702,'Java Database Connectivity',105302);

/*Table structure for table `request_details` */

DROP TABLE IF EXISTS `request_details`;

CREATE TABLE `request_details` (
  `id` int(11) NOT NULL,
  `bId` int(11) NOT NULL,
  `bookName` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `uId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`,`bId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `request_details` */

/*Table structure for table `seq` */

DROP TABLE IF EXISTS `seq`;

CREATE TABLE `seq` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `seq` */

insert into `seq` values 
(1301);

/*Table structure for table `seq1` */

DROP TABLE IF EXISTS `seq1`;

CREATE TABLE `seq1` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `seq1` */

insert into `seq1` values 
(1401);

/*Table structure for table `seq2` */

DROP TABLE IF EXISTS `seq2`;

CREATE TABLE `seq2` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `seq2` */

insert into `seq2` values 
(1301);

/*Table structure for table `seq3` */

DROP TABLE IF EXISTS `seq3`;

CREATE TABLE `seq3` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `seq3` */

insert into `seq3` values 
(6101);

/*Table structure for table `seq4` */

DROP TABLE IF EXISTS `seq4`;

CREATE TABLE `seq4` (
  `next_val` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `seq4` */

insert into `seq4` values 
(105701);

/*Table structure for table `users` */

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `uId` int(11) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` varchar(255) DEFAULT NULL,
  `userName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`uId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `users` */

insert into `users` values 
(105102,'padma@gmail.com','Padma@12','admin','Padma'),
(105202,'aravind@gmail.com','Aravind@12','admin','Aravind'),
(105302,'anudeep.boyapati333@gmail.com','Anu@14321','student','Anudeep'),
(105402,'aaa@gmail.com','Aaaaaa@1','admin','aaaaaa'),
(105506,'sai@gmail.com','Sai@1234','student','Sai kumar');
